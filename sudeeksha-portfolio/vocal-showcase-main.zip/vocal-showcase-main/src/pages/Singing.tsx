import HeroSection from "@/components/HeroSection";
import FeaturedPerformance from "@/components/FeaturedPerformance";
import PerformanceGallery from "@/components/PerformanceGallery";
import AboutArtist from "@/components/AboutArtist";
import CallToAction from "@/components/CallToAction";

const Singing = () => {
  return (
    <main className="min-h-screen bg-background">
      <HeroSection />
      <FeaturedPerformance />
      <PerformanceGallery />
      <AboutArtist />
      <CallToAction />
    </main>
  );
};

export default Singing;
