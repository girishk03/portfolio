import Singing from "./Singing";

const Index = () => {
  return <Singing />;
};

export default Index;

