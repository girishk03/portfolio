const performances = [
  {
    id: 1,
    title: "Acoustic Cover",
    embedId: "dQw4w9WgXcQ",
  },
  {
    id: 2,
    title: "Casual Live Session",
    embedId: "dQw4w9WgXcQ",
  },
];

const PerformanceGallery = () => {
  return (
    <section className="bg-background py-24 md:py-32">
      <div className="container mx-auto px-6 md:px-12 lg:px-20">
        {/* Section Header */}
        <div className="mb-12 text-center">
          <p className="mb-3 font-sans text-xs uppercase tracking-[0.3em] text-primary">
            More Performances
          </p>
          <h2 className="font-serif text-3xl font-medium text-foreground md:text-4xl">
            Gallery
          </h2>
        </div>

        {/* Video Grid */}
        <div className="mx-auto grid max-w-5xl gap-8 md:grid-cols-2">
          {performances.map((performance) => (
            <div key={performance.id} className="group">
              <div className="video-container aspect-video transition-all duration-500 group-hover:gold-glow">
                <iframe
                  src={`https://www.youtube.com/embed/${performance.embedId}`}
                  title={performance.title}
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                  allowFullScreen
                  className="h-full w-full"
                />
              </div>
              <p className="mt-4 text-center font-serif text-lg text-foreground/80">
                {performance.title}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default PerformanceGallery;
