import { Instagram, Youtube, Mail } from "lucide-react";

const socialLinks = [
  {
    name: "Instagram",
    icon: Instagram,
    href: "https://instagram.com",
  },
  {
    name: "YouTube",
    icon: Youtube,
    href: "https://youtube.com",
  },
  {
    name: "Email",
    icon: Mail,
    href: "mailto:contact@example.com",
  },
];

const CallToAction = () => {
  return (
    <section className="bg-background py-24 md:py-32">
      <div className="container mx-auto px-6 md:px-12 lg:px-20">
        <div className="mx-auto max-w-2xl text-center">
          {/* CTA Text */}
          <p className="mb-2 font-sans text-xs uppercase tracking-[0.3em] text-primary">
            Let's Connect
          </p>
          <h2 className="mb-8 font-serif text-2xl font-medium text-foreground md:text-3xl">
            Open to collaborations and live performances
          </h2>

          {/* Social Links */}
          <div className="flex justify-center gap-6">
            {socialLinks.map((link) => (
              <a
                key={link.name}
                href={link.href}
                target="_blank"
                rel="noopener noreferrer"
                aria-label={link.name}
                className="social-link text-muted-foreground"
              >
                <link.icon className="h-5 w-5" />
              </a>
            ))}
          </div>
        </div>
      </div>

      {/* Footer */}
      <div className="mt-24 border-t border-border">
        <div className="container mx-auto px-6 py-8 md:px-12 lg:px-20">
          <p className="text-center font-sans text-sm text-muted-foreground">
            © {new Date().getFullYear()} · All rights reserved
          </p>
        </div>
      </div>
    </section>
  );
};

export default CallToAction;
