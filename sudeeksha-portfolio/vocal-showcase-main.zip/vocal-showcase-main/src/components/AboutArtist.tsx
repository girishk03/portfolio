const AboutArtist = () => {
  return (
    <section className="section-gradient py-24 md:py-32">
      <div className="container mx-auto px-6 md:px-12 lg:px-20">
        <div className="mx-auto max-w-3xl text-center">
          {/* Section Header */}
          <p className="mb-3 font-sans text-xs uppercase tracking-[0.3em] text-primary">
            About
          </p>
          <h2 className="mb-10 font-serif text-3xl font-medium text-foreground md:text-4xl">
            The Voice
          </h2>

          {/* Bio Text */}
          <div className="space-y-6">
            <p className="font-sans text-lg leading-relaxed text-foreground/75 md:text-xl">
              Singing, for me, is where words fall short and emotion takes over. 
              There's a certain honesty that surfaces only when I'm performing—an 
              unfiltered connection with the music and everyone listening.
            </p>
            <p className="font-sans text-lg leading-relaxed text-foreground/75 md:text-xl">
              Whether it's the intimacy of an acoustic set or the energy of a live 
              stage, every performance is a conversation. I believe music carries 
              stories we don't always know how to tell otherwise.
            </p>
          </div>

          {/* Decorative Element */}
          <div className="mt-12 flex justify-center">
            <div className="h-[1px] w-24 bg-gradient-to-r from-transparent via-primary to-transparent" />
          </div>
        </div>
      </div>
    </section>
  );
};

export default AboutArtist;
